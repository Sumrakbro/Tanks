public class InvalidMapException extends Exception{
    InvalidMapException() {

    }
    InvalidMapException(String str){
        super(str);
    }

}
